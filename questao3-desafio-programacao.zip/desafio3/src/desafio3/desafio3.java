package desafio3;

import java.util.Arrays;
import javax.swing.JOptionPane;
import java.util.HashMap;
import java.util.Map.Entry;

public class desafio3 {

	public static void main(String[]args) {

		String anagrama = JOptionPane.showInputDialog(null, "Digite a palavra");
		
		HashMap<String, Integer> map = new HashMap<>();
		
		for (int i=0; i<anagrama.length(); i++) {
			for (int k=i; k<anagrama.length(); k++) {
				char[] anagrama2 = anagrama.substring(i, k+1).toCharArray();
				Arrays.sort(anagrama2);
				String a = new String(anagrama2);
				if (map.containsKey(a)) {
					map.put(a, map.get(a)+1);
				}else {
					map.put(a, 1);
				}
			}
		}
		
		int cont=0;
		
		for(Entry<String, Integer> e:map.entrySet()) {
			cont += (e.getValue()*(e.getValue()-1))/2;
		}
		System.out.println(cont);
		
	}
}