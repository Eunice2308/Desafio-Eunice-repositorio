package desafio;

import javax.swing.JOptionPane;
import static java.lang.Integer.*;

public class desafio1 {
	
	public static void main(String[]args) {
		
		int n = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o tamanho da escada"));
		int c=1;
		int cont=n;
		
		for(int i=1; i<=n; i++) {
			
			for(int a=1; a<cont; a++) {
				System.out.print(" ");
			}
			cont--;
			for(int b=0; b<c; b++) {
				System.out.print("*");
			}
			c++;
			System.out.println();
		}
	
	}
		
}