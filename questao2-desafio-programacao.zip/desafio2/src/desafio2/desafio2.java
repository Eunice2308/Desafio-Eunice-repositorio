package desafio2;

import javax.swing.JOptionPane;

public class desafio2 {
	
	public static void main(String[]args) {

	String caracteres = JOptionPane.showInputDialog(null, "Digite uma senha");
	
		if(caracteres.length()>=6) {		
			System.out.println("Senha segura.");		
		} else if(caracteres.length()<6){	
			int qtdCaracteresMin = 6 - caracteres.length();
			System.out.println("Quantidade de caracteres insuficientes, adicione mais "+ qtdCaracteresMin +" caractere");
		}
	
	}
}